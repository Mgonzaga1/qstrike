// 🚀 BACKGROUND CORS BYPASS PROXY
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "fetchFile") {
        fetch(request.url)
            .then(res => {
                if (!res.ok) throw new Error("Server response failed");
                const contentType = res.headers.get('content-type') || '';
                const contentDisposition = res.headers.get('content-disposition') || '';
                
                return res.arrayBuffer().then(buffer => {
                    sendResponse({
                        success: true,
                        data: Array.from(new Uint8Array(buffer)),
                        contentType: contentType,
                        contentDisposition: contentDisposition
                    });
                });
            })
            .catch(err => {
                sendResponse({ success: false, error: err.message });
            });
        return true; // Keep the message channel open for async response
    }
});