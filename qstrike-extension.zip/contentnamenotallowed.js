let parsedRowsData = [];
let loadedQaFileBlob = null; // Dito iimbak ang binuhat na file mula sa kahit anong folder
const hasStorage = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;

const styleEl = document.createElement('style');
styleEl.textContent = `
    #rosterEngineDrawer {
        position: fixed;
        top: 0;
        right: 0;
        width: 380px;
        height: 100vh;
        background: #1e1e24;
        color: #ffffff;
        z-index: 9999999;
        box-shadow: -5px 0 25px rgba(0,0,0,0.6);
        transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        font-family: 'Segoe UI', Arial, sans-serif;
        display: flex;
        flex-direction: column;
        border-left: 2px solid #3a3a42;
    }
    #rosterEngineDrawer.drawer-hidden {
        transform: translateX(100%);
    }
    #drawerToggleTab {
        position: fixed;
        top: 45%;
        right: 0;
        transform: translateY(-50%);
        background: #1e1e24;
        color: lime;
        border: 2px solid #3a3a42;
        border-right: none;
        padding: 15px 8px;
        cursor: pointer;
        z-index: 9999998;
        border-radius: 8px 0 0 8px;
        font-weight: bold;
        font-size: 11px;
        letter-spacing: 1px;
        box-shadow: -2px 2px 10px rgba(0,0,0,0.4);
        transition: all 0.2s ease;
        text-align: center;
    }

    #drawerToggleTab:hover { 
        background: #4dadff; 
        color: #1e1e24;
        padding-right: 15px; 
    }
    .drawer-header { background: #111115; padding: 14px; border-bottom: 1px solid #3a3a42; display: flex; justify-content: space-between; align-items: center; }
    .drawer-body { padding: 15px; flex: 1; overflow-y: auto; font-size: 13px; }
    .drawer-input-group { margin-bottom: 18px; }
    .drawer-input-group label { display: block; font-weight: bold; margin-bottom: 5px; color: #8a8a93; font-size: 12px; }
    .drawer-input-group input[type="text"], .drawer-input-group select { width: 100%; padding: 8px; background: #2b2b36; border: 1px solid #444; color: white; border-radius: 4px; box-sizing: border-box; }
    .drawer-btn { width: 100%; padding: 10px; font-weight: bold; border: none; border-radius: 6px; cursor: pointer; margin-bottom: 8px; color: white; font-size: 13px; }
    .btn-primary { background: #4dadff; color: #1e1e24; } .btn-primary:hover { background: #3593e6; }
    .btn-success { background: #28a745; } .btn-success:hover { background: #218838; }
    .btn-secondary { background: #6c757d; } .btn-secondary:hover { background: #5a6268; }
    .preview-item { background: #2b2b36; padding: 8px; border-radius: 4px; border: 1px solid #3a3a42; display: flex; align-items: center; margin-bottom: 6px; font-size: 11px; }
    .status-msg { font-size: 12px; margin-top: 8px; font-weight: bold; min-height: 18px; color: lime;
        white-space: pre-wrap;
        line-height: 1.2;
        background-color: #111115;
        border: 1px solid #3a3a42;
        border-radius: 6px;
        height: 60px;
        overflow-y: auto;
        font-family: 'Courier New', Courier, monospace;
        padding: 8px;
    }
`;

document.head.appendChild(styleEl);

const drawerContainer = document.createElement('div');
drawerContainer.id = 'rosterEngineDrawer';
drawerContainer.className = 'drawer-hidden';

drawerContainer.innerHTML = `
    <div class="drawer-header">
        <span style="font-weight:bold; font-size:14px; color:#4dadff;">⚡ Auto-generate Folder Beta 1.0</span>
        <button id="hideDrawerBtn" style="background:#d9534f; color:white; border:none; padding:4px 8px; font-size:11px; cursor:pointer; border-radius:4px; font-weight:bold;">👉 Hide >></button>
    </div>


    <div class="drawer-body">

<div style="align-items:center; cursor:pointer; font-size:12px; color: #ecc94b; gap: 4px; top: 52px; position: absolute; right: 30px;">
<input type="checkbox" id="autoHideChk" checked style="transform: scale(1.1); display: inline-flex;">&nbsp; Enable Auto-Hide</div>


        <div id="statusOutput" class="status-msg">System Ready. Awaiting instructions... Charrr! xD</div>


        <div id="inputSection">
            <div class="drawer-input-group">
                <label>Enter Order Number:</label>
                <input type="text" id="orderFilterInput" placeholder="Ex: 26012345">
            </div>
            <button id="scrapeBtn" class="drawer-btn btn-primary">🔍 Preview & Process Order Number</button>
        </div>

        <div id="previewContainer" style="display:none;">
            <div class="drawer-input-group"><br>
                <label>GA Folder Name:</label>
                <input type="text" id="gaFolderInput" value="sourcefiles_" placeholder="Ex: sourcefiles_manny">
            </div>
            <div class="drawer-input-group">
                <label>Filter by Factory Engine:</label>
                <select id="factoryFilterSelect"></select>
            </div>
            


            <div style="background:#111115; padding:10px; border-radius:4px; margin-bottom:10px; border:1px solid #3a3a42;">
                <label style="display:block; margin-bottom:6px; font-weight:bold; font-size:11px; color:#8a8a93;">Bulk System Controls:</label>

                <label style="display:flex; align-items:center; cursor:pointer; font-size:11px; margin-top:6px; color:#4dadff;">
                    <input type="checkbox" id="includeFolder3Chk" style="margin-right:6px;"> Include Vector Logo Folder
                </label>
                
                <div style="margin-top: 6px;">
                    <label style="display:flex; align-items:center; cursor:pointer; font-size:11px; color:#a78bfa; font-weight:bold;">
                        <input type="checkbox" id="includeQaChk" checked style="margin-right:6px;"> Include Checklist Files
                    </label>
                    <div id="qaInputWrapper" style="margin-top: 6px; padding-left: 18px;">
                        <input type="file" id="qaFilePicker" style="width:100%; color:#a78bfa; font-size:11px; cursor:pointer;">
                        <div id="qaFileCacheNotice" style="font-size:10px; color:#8a8a93; margin-top:3px; font-style:italic;"></div>
                    </div>
                </div>
            </div>




            <label style="font-weight:bold; font-size:12px; color:#8a8a93; display:block; margin-bottom:5px;"> Folder Output Sequence Preview: </label>

		<label style="display:inline-flex; align-items:center; cursor:pointer; font-size:11px; color: #ecc94b;">
                    <input type="checkbox" id="appendAnxChk" style="margin-right:6px;"> ANX 
                </label>
                &nbsp;&nbsp;
                <label style="display:inline-flex; align-items:center; cursor:pointer; font-size:11px; color:#fff;">
                    <input type="checkbox" id="masterSelectAll" checked style="margin-right:6px;"> Folders (All)
                </label>


            <div id="previewList" style="max-height:240px; overflow-y:auto; margin-bottom:12px; border-top:1px solid #3a3a42; padding-top:5px;"></div>
            
            <button id="runBtn" class="drawer-btn btn-success">⚡ Generate Folders & Files</button>
            <button id="backBtn" class="drawer-btn btn-secondary">⬅️ Enter New Order Number</button>
        </div>
    </div>
`;

const toggleTab = document.createElement('div');
toggleTab.id = 'drawerToggleTab';
toggleTab.innerHTML = '◀<br>O<br>P<br>E<br>N';

document.body.appendChild(drawerContainer);
document.body.appendChild(toggleTab);

toggleTab.addEventListener('click', () => {
    drawerContainer.classList.remove('drawer-hidden');
    toggleTab.style.display = 'none';
});

document.getElementById('hideDrawerBtn').addEventListener('click', () => {
    drawerContainer.classList.add('drawer-hidden');
    toggleTab.style.display = 'block';
});

// --- 🚀 SMART AUTO-HIDE CONTROLLER ---
let autoHideTimeout;
drawerContainer.addEventListener('mouseleave', () => {
    const isAutoHideEnabled = document.getElementById('autoHideChk')?.checked ?? true;
    if (!isAutoHideEnabled) return;

    autoHideTimeout = setTimeout(() => {
        drawerContainer.classList.add('drawer-hidden');
        toggleTab.style.display = 'block';
    }, 600);
});

drawerContainer.addEventListener('mouseenter', () => {
    if (autoHideTimeout) clearTimeout(autoHideTimeout);
});

toggleTab.addEventListener('mouseenter', () => {
    const isAutoHideEnabled = document.getElementById('autoHideChk')?.checked ?? true;
    if (!isAutoHideEnabled) return;

    drawerContainer.classList.remove('drawer-hidden');
    toggleTab.style.display = 'none';
});


// --- ENGINE CODE CORE ---
function ensureHttps(url) {
    if (!url) return url;
    return url.startsWith('http://') ? url.replace('http://', 'https://') : url;
}

function sanitizeName(name) {
    if (!name) return "";
    return name.replace(/[\\/:*?"<>|]/g, ' ').replace(/\s+/g, ' ').trim();
}

function getFilenameFromHeadersAndUrl(disposition, targetUrl, fallbackName) {
    let filename = "";
    if (disposition) {
        const utf8Matches = /filename\*=UTF-8''([^;\n]*)/i.exec(disposition);
        if (utf8Matches && utf8Matches[1]) filename = decodeURIComponent(utf8Matches[1]);
        else {
            const matches = /filename=["']?([^"';\n]*)["']?/.exec(disposition);
            if (matches && matches[1]) filename = matches[1];
        }
    }
    if (!filename && targetUrl) {
        try {
            const url = new URL(targetUrl);
            for (let param of url.searchParams.values()) {
                if (param.includes('.') && !param.toLowerCase().endsWith('.aspx')) {
                    filename = param.split('/').pop();
                    break;
                }
            }
            if (!filename) {
                const pathName = url.pathname.split('/').pop();
                if (pathName && pathName.includes('.') && !pathName.toLowerCase().endsWith('.aspx')) {
                    filename = pathName;
                }
            }
        } catch (e) {}
    }
    if (!filename) return fallbackName;
    const lastDot = filename.lastIndexOf('.');
    if (lastDot !== -1) {
        return sanitizeName(filename.substring(0, lastDot)) + filename.substring(lastDot);
    }
    return sanitizeName(filename);
}

function updateFactoryOptions(orderSpecificRows) {
    const factoryFilterSelect = document.getElementById('factoryFilterSelect');
    if (!factoryFilterSelect) return;
    const uniqueFactories = [...new Set(orderSpecificRows.map(row => row.factory).filter(item => item && item.trim() !== ''))];
    factoryFilterSelect.innerHTML = '';
    uniqueFactories.forEach(fac => {
        const opt = document.createElement('option');
        opt.value = fac; opt.innerText = fac;
        factoryFilterSelect.appendChild(opt);
    });
}


//start ng checklist file loaded

function saveCurrentStateToStorage() {
    if (!hasStorage) return;
    const state = {
        savedRowsData: parsedRowsData,
        targetOrderNum: document.getElementById('orderFilterInput')?.value.trim() || '',
        targetFactory: document.getElementById('factoryFilterSelect')?.value || '',
        gaFolderValue: document.getElementById('gaFolderInput')?.value.trim() || '',
        includeFolder3: document.getElementById('includeFolder3Chk')?.checked || false,
        includeQaChecklist: document.getElementById('includeQaChk')?.checked || false,
        lastLoadedFilename: document.getElementById('qaFileCacheNotice')?.innerText.replace("Last file ", "") || '',
        appendAnxMaster: document.getElementById('appendAnxChk')?.checked || false,
        inPreviewMode: document.getElementById('previewContainer')?.style.display === 'block',
        autoHideMaster: document.getElementById('autoHideChk')?.checked ?? true
    };
    chrome.storage.local.set(state);
}

if (hasStorage) {
    chrome.storage.local.get(['savedRowsData', 'targetOrderNum', 'targetFactory', 'gaFolderValue', 'includeFolder3', 'includeQaChecklist', 'lastLoadedFilename', 'appendAnxMaster', 'inPreviewMode', 'autoHideMaster'], (result) => {
        if (result.targetOrderNum) document.getElementById('orderFilterInput').value = result.targetOrderNum;
        if (result.gaFolderValue) document.getElementById('gaFolderInput').value = result.gaFolderValue;
        if (result.includeFolder3) document.getElementById('includeFolder3Chk').checked = result.includeFolder3;
        if (result.hasOwnProperty('includeQaChecklist')) {
            document.getElementById('includeQaChk').checked = result.includeQaChecklist;
            document.getElementById('qaInputWrapper').style.display = result.includeQaChecklist ? 'block' : 'none';
        }
        if (result.lastLoadedFilename) {
            document.getElementById('qaFileCacheNotice').innerText = `Last file ${result.lastLoadedFilename}`;
        }
        if (result.appendAnxMaster) document.getElementById('appendAnxChk').checked = blockAnxCheckState(result.appendAnxMaster);
        
        if (result.hasOwnProperty('autoHideMaster')) {
            document.getElementById('autoHideChk').checked = result.autoHideMaster;
        }

        if (result.savedRowsData && result.savedRowsData.length > 0 && result.inPreviewMode) {
            parsedRowsData = result.savedRowsData;
            updateFactoryOptions(parsedRowsData.map(item => item.lineText).filter(row => row.orderNum === result.targetOrderNum));
            if (result.targetFactory) document.getElementById('factoryFilterSelect').value = result.targetFactory;
            rebuildUiFromCache();
            document.getElementById('inputSection').style.display = 'none';
            document.getElementById('previewContainer').style.display = 'block';
        }
    });
}




function blockAnxCheckState(val) {
    const el = document.getElementById('appendAnxChk');
    if(el) el.checked = val;
    return val;
}

document.getElementById('orderFilterInput').addEventListener('input', saveCurrentStateToStorage);
document.getElementById('gaFolderInput').addEventListener('input', saveCurrentStateToStorage);
document.getElementById('includeFolder3Chk').addEventListener('change', saveCurrentStateToStorage);
document.getElementById('autoHideChk').addEventListener('change', saveCurrentStateToStorage);
document.getElementById('factoryFilterSelect').addEventListener('change', () => { rebuildUiFromCache(); saveCurrentStateToStorage(); });

document.getElementById('includeQaChk').addEventListener('change', function() {
    document.getElementById('qaInputWrapper').style.display = this.checked ? 'block' : 'none';
    saveCurrentStateToStorage();
});

// 🚀 EVENT LISTENER PARA SA BROWSE BUTTON
document.getElementById('qaFilePicker').addEventListener('change', function(e) {
    if (e.target.files.length > 0) {
        loadedQaFileBlob = e.target.files[0];
        document.getElementById('qaFileCacheNotice').innerText = `Loaded: ${loadedQaFileBlob.name}`;
        saveCurrentStateToStorage();
    }
});

document.addEventListener('change', (e) => {
    if (e.target.classList.contains('folder-chk') || e.target.classList.contains('anx-item-chk')) {
        const idx = parseInt(e.target.getAttribute('data-index'), 10);
        if (isNaN(idx) || !parsedRowsData[idx]) return;
        if (e.target.classList.contains('folder-chk')) parsedRowsData[idx].isFolderChecked = e.target.checked;
        else if (e.target.classList.contains('anx-item-chk')) parsedRowsData[idx].isAnxChecked = e.target.checked;
        saveCurrentStateToStorage();
    }
});

function rebuildUiFromCache() {
    const previewList = document.getElementById('previewList');
    if (!previewList) return;
    previewList.innerHTML = "";
    const uiFragment = document.createDocumentFragment();
    const selectedFactory = document.getElementById('factoryFilterSelect')?.value || '';
    let dynamicUiSequence = 1;

    parsedRowsData.forEach((item, idx) => {
        const data = item.lineText;
        if (selectedFactory && data.factory !== selectedFactory) return;
        
        const sequenceNumber = dynamicUiSequence++;
        item.currentUiSeq = sequenceNumber; 

        const itemDiv = document.createElement('div');
        itemDiv.className = 'preview-item';
        itemDiv.innerHTML = `
            <label style="display: inline-flex; align-items: center; margin-right: 8px; font-weight: bold; color: #ecc94b; cursor: pointer;">
                <input type="checkbox" class="anx-item-chk" data-index="${idx}" ${item.isAnxChecked ? "checked" : ""} style="margin-right:4px;">ANX
            </label>
            <input type="checkbox" class="folder-chk" data-index="${idx}" ${item.isFolderChecked ? "checked" : ""}>
            <span style="margin-left: 6px;"><strong>[#${sequenceNumber}]</strong> ${data.orderPart}, ${data.description} <span style="color:#8a8a93;">(${data.factory})</span></span>
        `;
        uiFragment.appendChild(itemDiv);
    });
    previewList.appendChild(uiFragment);
}

document.getElementById('scrapeBtn').addEventListener('click', async () => {
    const targetOrderNum = document.getElementById('orderFilterInput').value.trim();
    const status = document.getElementById('statusOutput');
    if (!targetOrderNum) { alert("Error: Maglagay ng Order Number!"); return; }

    status.innerText = `Checking sa Order #${targetOrderNum}...`;
    status.style.color = "cyan";
    parsedRowsData = [];

    const targetRows = document.querySelectorAll('table tbody tr');
    let orderRows = [];
    for (let i = 0; i < targetRows.length; i++) {
        const cells = targetRows[i].querySelectorAll('td');
        if (cells.length >= 8) {
            const orderNum = cells[0].innerText.trim();
            if (orderNum === targetOrderNum) {
                const linkEl = cells[0].querySelector('a');
                orderRows.push({
                    orderNum: orderNum, orderLink: linkEl ? linkEl.href : "",
                    orderPart: cells[1].innerText.trim(), factory: cells[2].innerText.trim(),
                    clientName: cells[6].innerText.trim(), description: cells[7].innerText.trim()
                });
            }
        }
    }

    if (orderRows.length === 0) { alert(`Walang nahanap para sa Order #${targetOrderNum}`); status.innerText = ""; return; }
    updateFactoryOptions(orderRows);
    status.innerText = `Nahanap! Kinukuha ang layout system ng bawat item... Maghintay lang.`;

    for (let i = 0; i < orderRows.length; i++) {
        const row = orderRows[i];
        let scanResult = { holdsData: false, reorderId: "", reorderPartId: "" };
        if (row.orderLink) scanResult = await evaluateRosterLinkDirectly(row.orderLink); 
        
        parsedRowsData.push({
            lineText: { ...row, isRealRoster: scanResult.holdsData, reorderId: scanResult.reorderId, reorderPartId: scanResult.reorderPartId },
            sequenceNumber: i + 1, totalRows: orderRows.length,
            isFolderChecked: true, isAnxChecked: scanResult.holdsData
        });
    }

    rebuildUiFromCache();
    status.style.color = "lime";
    status.innerText = "Yown! Okay na. Ready to generate...";
    document.getElementById('inputSection').style.display = 'none';
    document.getElementById('previewContainer').style.display = 'block';
    saveCurrentStateToStorage();
});

async function secureAndFallbackFetch(url) {
    if (!url) return { success: false };
    let safeUrl = ensureHttps(url);
    
    try {
        let res = await fetch(safeUrl);
        if (res.ok) return { success: true, res };
    } catch (e) {}

    try {
        const response = await new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({ action: "fetchFile", url: safeUrl }, (reply) => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve(reply);
                }
            });
        });
        
        if (response && response.success) {
            const u8 = new Uint8Array(response.data);
            const blob = new Blob([u8], { type: response.contentType });
            const mockResponse = new Response(blob, {
                headers: {
                    'content-type': response.contentType,
                    'content-disposition': response.contentDisposition
                }
            });
            return { success: true, res: mockResponse };
        }
    } catch (err) {
        if (safeUrl !== url) {
            try {
                let res = await fetch(url);
                if (res.ok) return { success: true, res };
            } catch (e) {}
        }
    }
    return { success: false };
}

async function evaluateRosterLinkDirectly(url) {
    let result = { holdsData: false, reorderId: "", reorderPartId: "" };
    if (!url) return result;
    const fetchCall = await secureAndFallbackFetch(url);
    if (!fetchCall.success) return result;
    
    const htmlText = await fetchCall.res.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlText, 'text/html');
    const pageText = doc.body ? doc.body.innerHTML.replace(/<[^>]+>/g, ' ') : "";
    
    const rId = pageText.match(/Reorder\s+ID:\s*([A-Za-z0-9]+)/i);
    const rpId = pageText.match(/Reorder\s+Part\s+ID:\s*([A-Za-z0-9]+)/i);
    if (rId) result.reorderId = rId[1].trim();
    if (rpId) result.reorderPartId = rpId[1].trim();

    const tables = doc.querySelectorAll('table');
    for (let t = 0; t < tables.length; t++) {
        const trs = tables[t].querySelectorAll('tr');
        if (trs.length < 2) continue;
        let numIdx = -1, nameIdx = -1, headerRowIdx = -1;

        for (let i = 0; i < Math.min(trs.length, 3); i++) {
            trs[i].querySelectorAll('th, td').forEach((cell, idx) => {
                const txt = cell.textContent.replace(/[\s\xa0]+/g, ' ').trim().toLowerCase();
                if (['number', 'num', '#', 'jersey', 'pos'].some(k => txt.includes(k))) numIdx = idx;
                if (['player', 'roster', 'member', 'name'].some(k => txt.includes(k)) && !['client','factory'].some(k=>txt.includes(k))) nameIdx = idx;
            });
            if (numIdx !== -1 || nameIdx !== -1) { headerRowIdx = i; break; }
        }
        if (headerRowIdx !== -1) {
            let valid = 0;
            for (let j = headerRowIdx + 1; j < trs.length; j++) {
                const dataCells = trs[j].querySelectorAll('td');
                if (dataCells.length === 0) continue;
                let hasVal = false;
                if (numIdx !== -1 && dataCells[numIdx] && dataCells[numIdx].textContent.trim().length > 0) hasVal = true;
                if (nameIdx !== -1 && dataCells[nameIdx] && dataCells[nameIdx].textContent.trim().length > 0) hasVal = true;
                if (hasVal) valid++;
            }
            if (valid > 0) { result.holdsData = true; break; }
        }
    }
    return result;
}

async function downloadFileDirectlyFromSidepanel(webpageUrl, allowCsv) {
    let result = { textData: "", primaryFile: null, csvFile: null };
    let pageFetch = await secureAndFallbackFetch(webpageUrl);
    if (!pageFetch.success) return { success: false };
    result.textData = await pageFetch.res.text();
    
    const parser = new DOMParser();
    const doc = parser.parseFromString(result.textData, 'text/html');
    const candidates = doc.querySelectorAll('a, button, input[type="submit"]');
    let potentialTriggers = [];
    
    candidates.forEach(el => {
        const href = el.getAttribute('href') || "";
        const text = (el.innerText || el.textContent || "").toLowerCase();
        const hrefLower = href.toLowerCase();
        
        if (!href || href === '#' || href.startsWith('javascript:')) return;
        
        if (hrefLower.includes('csv') || text.includes('csv') || text.includes('export')) {
            result.csvFile = { success: true, href: href }; 
            return; 
        }
        
        const hasPdfExtension = hrefLower.includes('.pdf');
        const hasImageExtension = hrefLower.includes('.jpg') || hrefLower.includes('.jpeg') || hrefLower.includes('.png');
        const hasKeyWords = ['download', 'full size', 'proof', 'artwork', 'print', 'view', 'pdf'].some(k => text.includes(k));
        
        if (hasPdfExtension || hasImageExtension || hasKeyWords) {
            let score = 0;
            if (hasPdfExtension) score += 60;
            if (text.includes('pdf')) score += 30;
            if (text.includes('proof') || text.includes('artwork')) score += 25;
            if (text.includes('full size')) score += 20;
            if (text.includes('download') || text.includes('view') || text.includes('print')) score += 10;
            if (hasImageExtension) score += 15;
            
            potentialTriggers.push({ href: href, isWindowOpen: false, score: score });
        }
    });
    
    if (potentialTriggers.length > 0) {
        potentialTriggers.sort((a, b) => b.score - a.score);
        result.primaryFile = await executeTriggerDownload(potentialTriggers[0], doc, webpageUrl);
    }
    
    if (allowCsv && result.csvFile && result.csvFile.href) {
        result.csvFile = await executeTriggerDownload(result.csvFile, doc, webpageUrl);
    }
    
    return { success: true, ...result };
}

async function executeTriggerDownload(trigger, doc, webpageUrl) {
    try {
        let finalFileUrl = new URL(trigger.isWindowOpen ? trigger.windowOpenUrl : trigger.href, webpageUrl).href;
        let fileFetch = await secureAndFallbackFetch(finalFileUrl);
        if (!fileFetch.success) return { success: false };
        const buffer = await fileFetch.res.arrayBuffer();
        return { success: true, buffer: Array.from(new Uint8Array(buffer)), contentType: fileFetch.res.headers.get('content-type') || '', contentDisposition: fileFetch.res.headers.get('content-disposition') || '', finalUrl: finalFileUrl };
    } catch { return { success: false }; }
}

document.getElementById('masterSelectAll').addEventListener('change', function() {
    document.querySelectorAll('#previewList .folder-chk').forEach(c => { c.checked = this.checked; c.dispatchEvent(new Event('change')); });
});

document.getElementById('appendAnxChk').addEventListener('change', function() {
    document.querySelectorAll('.anx-item-chk').forEach(c => { c.checked = this.checked; const idx = parseInt(c.getAttribute('data-index'),10); if(parsedRowsData[idx]) parsedRowsData[idx].isAnxChecked = this.checked; });
    saveCurrentStateToStorage();
});

document.getElementById('backBtn').addEventListener('click', () => {
    document.getElementById('inputSection').style.display = 'block';
    document.getElementById('previewContainer').style.display = 'none';
    document.getElementById('statusOutput').innerText = "Ready na ulit...";
    parsedRowsData = []; saveCurrentStateToStorage();
});

document.getElementById('runBtn').addEventListener('click', async () => {
    const gaFolderValue = document.getElementById('gaFolderInput').value.trim();
    if (!gaFolderValue) { alert("Error: Maglagay ng GA Folder!"); return; }
    
    let selectedItems = [];
    document.querySelectorAll('.folder-chk').forEach(chk => {
        if (chk.checked) {
            const idx = parseInt(chk.getAttribute('data-index'), 10);
            const parentRow = chk.closest('.preview-item');
            const anxChecked = parentRow?.querySelector('.anx-item-chk')?.checked || false;
            if (parsedRowsData[idx]) {
                selectedItems.push({ 
                    rowData: parsedRowsData[idx], 
                    isAnxActive: anxChecked,
                    uiSeq: parsedRowsData[idx].currentUiSeq
                });
            }
        }
    });
    if (selectedItems.length === 0) { alert("Error: Pumili ng folder!"); return; }

    const status = document.getElementById('statusOutput');
    const includeFolder3 = document.getElementById('includeFolder3Chk').checked;
    const includeQa = document.getElementById('includeQaChk').checked;
    const selectedFactory = document.getElementById('factoryFilterSelect').value.trim();
    const totalVisibleRows = parsedRowsData.filter(item => !selectedFactory || item.lineText.factory === selectedFactory).length;

    let qaBlob = null;
    let qaFilename = "";

    if (includeQa) {
        if (!loadedQaFileBlob) {
            alert("Error: Nakalimutan mo ang Checklist File.Click 'Browse/Choose File' at hanapin ang file!");
            status.innerText = "❌ Wuuyyy! Wala pang CHECKLIST!! ";
            status.style.color = "orange";
            return;
        }
        qaBlob = loadedQaFileBlob;
        qaFilename = loadedQaFileBlob.name;
    }

    try {
        const rootHandle = await window.showDirectoryPicker({ mode: 'readwrite' });
        const startTime = performance.now();

        const uniqueFactories = [...new Set(parsedRowsData.map(item => item.lineText.factory).filter(f => f))];
        const hasMultipleFactories = uniqueFactories.length > 1;
        let reorderContent = "RE-ORDER (ONLY)\n\n";
        let hasReorder = false;

        for (let i = 0; i < selectedItems.length; i++) {
            const item = selectedItems[i];
            const rawLine = item.rowData.lineText;
            status.innerText = `⏳ [${i+1}/${selectedItems.length}] Processing: Order ${rawLine.orderPart}...`;
            
            await buildAutomatedFolders(rawLine, rootHandle, totalVisibleRows, item.uiSeq, gaFolderValue, includeFolder3, item.isAnxActive, selectedFactory, hasMultipleFactories, qaBlob, qaFilename);
            
            if (rawLine.reorderId || rawLine.reorderPartId) {
                hasReorder = true;
                reorderContent += `${item.uiSeq}\nReorder ID: ${rawLine.reorderId || ''}\nReorder Part ID: ${rawLine.reorderPartId || ''}\n\n`;
            }
        }

        if (hasReorder) {
            const firstItem = selectedItems[0].rowData.lineText;
            let folder1 = sanitizeName(`${firstItem.orderNum} ${firstItem.clientName}`);
            if (hasMultipleFactories && selectedFactory) folder1 += `_${sanitizeName(selectedFactory)}`;
            const gaFolderHandle = await getDeepFolder(rootHandle, `${folder1}\\${sanitizeName(gaFolderValue)}`);
            await saveFileDirectly(gaFolderHandle, "reorder.txt", reorderContent);
        }

        const endTime = performance.now();
        const totalDuration = ((endTime - startTime) / 1000).toFixed(2);

        status.style.color = "lime";
        status.innerText = `🎉 Done! [sa loob ng ${totalDuration}seconds]\nFolders created. Checklist added!`;
    } catch (err) { if (err.name !== 'AbortError') alert("Error: " + err.message); }
});

async function getDeepFolder(rootHandle, pathString) {
    let currentHandle = rootHandle;
    for (const part of pathString.split('\\')) { if (part) currentHandle = await currentHandle.getDirectoryHandle(part, { create: true }); }
    return currentHandle;
}

async function buildAutomatedFolders(rowData, rootHandle, totalRows, sequenceNumber, customGaFolder, includeFolder3, appendAnx, selectedFactory, hasMultipleFactories, qaBlob, qaFilename) {
    const orderNum = sanitizeName(rowData.orderNum), orderPart = sanitizeName(rowData.orderPart), clientName = sanitizeName(rowData.clientName), description = sanitizeName(rowData.description), gaFolder = sanitizeName(customGaFolder);
    const factorySuffix = (hasMultipleFactories && selectedFactory) ? `_${sanitizeName(selectedFactory)}` : '';
    
    let seqPrefix = totalRows > 1 ? `${sequenceNumber} ` : "";
    let folder1 = `${orderNum} ${clientName}`; if (factorySuffix) folder1 += factorySuffix;
    let folder2 = `${folder1}\\${seqPrefix}${orderPart}, ${description}${appendAnx ? "_ANX" : ""}`;
        
    await getDeepFolder(rootHandle, folder2);
    
    const filesFolderHandle = await getDeepFolder(rootHandle, `${folder1}\\${gaFolder}\\${seqPrefix}${orderPart}\\FILES`);
    await getDeepFolder(rootHandle, `${folder1}\\${gaFolder}\\${seqPrefix}${orderPart}\\PDF`);
    if (includeFolder3) await getDeepFolder(rootHandle, `${folder1}\\${gaFolder}\\${clientName}`);

    if (qaBlob && qaFilename) {
        await saveFileDirectly(filesFolderHandle, qaFilename, qaBlob);
    }

    if (!rowData.orderLink) return;
    try {
        let dl = await downloadFileDirectlyFromSidepanel(rowData.orderLink, appendAnx);
        if (!dl.success) return;
        if (dl.textData) await saveFileDirectly(filesFolderHandle, sanitizeName(`Order_${rowData.orderNum}_Part_${rowData.orderPart}.html`), dl.textData);
        
        let primaryFileNameCaptured = "";
        if (dl.primaryFile && dl.primaryFile.success) {
            let ext = dl.primaryFile.contentType.includes('image') ? '.jpg' : '.pdf';
            let fn = getFilenameFromHeadersAndUrl(dl.primaryFile.contentDisposition, dl.primaryFile.finalUrl, `${seqPrefix}${orderPart}${ext}`);
            primaryFileNameCaptured = fn.substring(0, fn.lastIndexOf('.'));
            await saveFileDirectly(filesFolderHandle, fn, new Blob([new Uint8Array(dl.primaryFile.buffer)], { type: dl.primaryFile.contentType }));
        }
        
        if (appendAnx && dl.csvFile && dl.csvFile.success) {
            let fallbackCsvName = primaryFileNameCaptured ? `${primaryFileNameCaptured}.csv` : `${seqPrefix}${orderPart}_Data.csv`;
            let fn = getFilenameFromHeadersAndUrl(dl.csvFile.contentDisposition, dl.csvFile.finalUrl, fallbackCsvName);
            if(!fn.toLowerCase().endsWith('.csv')) fn += '.csv';
            await saveFileDirectly(filesFolderHandle, fn, new Blob([new Uint8Array(dl.csvFile.buffer)], { type: 'text/csv' }));
        }
    } catch {}
}

async function saveFileDirectly(directoryHandle, filename, content) {
    const fileHandle = await directoryHandle.getFileHandle(filename, { create: true });
    const writable = await fileHandle.createWritable();
    await writable.write(content); 
    await writable.close();
}